from django.apps import AppConfig


class HackConfig(AppConfig):
    name = 'hack'
